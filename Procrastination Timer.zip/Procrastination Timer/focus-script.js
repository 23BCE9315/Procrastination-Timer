const startBtn = document.getElementById("startBtn");
const timerDisplay = document.getElementById("timer");
const rewardBox = document.getElementById("reward");
const quoteText = document.getElementById("quote");
const memeImage = document.getElementById("meme");
const streakCount = document.getElementById("streakCount");

// Sample quotes
const quotes = [
  "You're closer than you think. 🚀",
  "Great things take time. Keep going. 💪",
  "Discipline is choosing what you want most. 🔥",
  "You're not behind. You're just getting started. ✨",
  "Success starts with the next step. 👣"
];

// Instagram meme links
const memeLinks = [
   "c:\Users\DELL\OneDrive\Desktop\monkey.jpg",
  "https://www.instagram.com/p/DHmUL_stomw/?igsh=cHN2ZW5yb2wzNm5r",
  "https://www.instagram.com/p/DH-rzRJOJGX/?igsh=MW52bXJvZTI3d2dnaw==",
  "https://www.instagram.com/p/DHshRgOutEa/?igsh=ZzB4bWhxcmxkdGJ3",
  "https://www.instagram.com/p/DE_0lUNSO2Q/?igsh=MWhjbDU2MHd3bXN4Mg=="
];

let memeQueue = shuffleArray([...memeLinks]);

function shuffleArray(array) {
  // Fisher-Yates Shuffle
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// Load streak from localStorage
let streak = localStorage.getItem("streak") || 0;
streakCount.textContent = streak;

startBtn.addEventListener("click", () => {
  startBtn.disabled = true;
  let minutes =0;
  let seconds = 10;

  const interval = setInterval(() => {
    timerDisplay.textContent = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;

    if (minutes === 0 && seconds === 0) {
      clearInterval(interval);
      showReward();
    }

    if (seconds === 0) {
      minutes--;
      seconds = 10;
    } else {
      seconds--;
    }
  }, 1000);
});

function showReward() {
  rewardBox.classList.remove("hidden");

  const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
  quoteText.textContent = randomQuote;

  // Get next meme from queue
  let memeURL = memeQueue.shift();
  if (!memeURL) {
    memeQueue = shuffleArray([...memeLinks]);
    memeURL = memeQueue.shift();
  }

  memeImage.src = "https://upload.wikimedia.org/wikipedia/commons/5/5e/Instagram-Icon.png";
  memeImage.style.cursor = "pointer";
  memeImage.onclick = () => window.open(memeURL, "_blank");

  // Update streak
  streak++;
  localStorage.setItem("streak", streak);
  streakCount.textContent = streak;

  startBtn.disabled = false;
}